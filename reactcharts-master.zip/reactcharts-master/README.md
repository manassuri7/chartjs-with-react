# ReachCharts App

Example app showing you how to use react-chartjs-2 in a project

## Install Dependencies
```bash
npm install 
```

## Run Dev Server
```bash
npm start
```

## Build To Dist Folder
```bash
npm run build
```